import React from 'react'

function Contact() {
  return (
    <>
  <div className="container-fluid">
    <div className="row">
      <div className="col-12">
        <div
          className="page-header flex justify-content-center align-items-center"
          style={{ backgroundImage: 'url("images/contact-bg.jpg")' }}
        >
          <h1>Contact</h1>
        </div>
        {/* .page-header */}
      </div>
      {/* .col */}
    </div>
    {/* .row */}
    <div className="container">
      <div className="row">
        <div className="offset-lg-9 col-lg-3">
          <a href="#">
            <div className="yt-subscribe">
              <img src="images/yt-subscribe.png" alt="Youtube Subscribe" />
              <h3>Subscribe</h3>
              <p>To my Youtube Channel</p>
            </div>
            {/* .yt-subscribe */}
          </a>
        </div>
        {/* .col */}
      </div>
      {/* .row */}
    </div>
    {/* .container */}
  </div>
  {/* .hero-section */}
  <div className="container single-page contact-page">
    <div className="row">
      <div className="col-12 col-lg-9">
        <div className="content-wrap">
          <header className="entry-header">
            <h2 className="entry-title">Contact me or just say HI</h2>
            <div className="tags-links">
              <a href="#">#winter</a>
              <a href="#">#love</a>
              <a href="#">#snow</a>
              <a href="#">#january</a>
            </div>
            {/* .tags-links */}
          </header>
          {/* .entry-header */}
          <div className="entry-content">
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent
              vel tortor facilisis, volutpat nulla placerat, tincidunt mi.
              Nullam vel orci dui. Suspendisse sit amet laoreet neque. Fusce
              sagittis suscipit sem a consequat. Proin nec interdum sem. Quisque
              in porttitor magna, a imperdiet est. Donec accumsan justo nulla,
              sit amet varius urna laoreet vitae. Maecenas feugiat fringilla
              metus. Nullam semper ornare quam eu sagittis. Curabitur ornare sem
              eu dapibus rutrum. Sed lobortis eros ut sapien lobortis, euismod
              dignissim odio interdum. Integer finibus molestie tellus sit amet
              egestas. Aliquam ullamcorper magna in ipsum sollicitudin imperdiet
              consectetur vitae nunc. Maecenas vel erat et erat lobortis
              porttitor ac id diam.{" "}
            </p>
          </div>
          {/* .entry-content */}
          <div className="contact-page-social">
            <ul className="flex align-items-center">
              <li>
                <a href="#">
                  <i className="fa fa-pinterest" />
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="fa fa-facebook" />
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="fa fa-twitter" />
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="fa fa-dribbble" />
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="fa fa-behance" />
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="fa fa-linkedin" />
                </a>
              </li>
            </ul>
          </div>
          {/* .header-bar-social */}
          <form className="contact-form">
            <input type="text" placeholder="Name" />
            <input type="email" placeholder="Email" />
            <textarea
              rows={18}
              cols={6}
              placeholder="Messages"
              defaultValue={""}
            />
            <input type="submit" defaultValue="Read More" />
          </form>
          {/* .contact-form */}
        </div>
        {/* .content-wrap */}
      </div>
      {/* .col */}
      <div className="col-12 col-lg-3">
        <div className="sidebar">
          <div className="recent-posts">
            <div className="recent-post-wrap">
              <figure>
                <img src="images/thumb-1.jpg" alt="" />
              </figure>
              <header className="entry-header">
                <div className="posted-date">January 30, 2018</div>
                {/* .entry-header */}
                <h3>
                  <a href="#">My fall in love story</a>
                </h3>
                <div className="tags-links">
                  <a href="#">#winter</a>
                  <a href="#">#love</a>
                  <a href="#">#snow</a>
                  <a href="#">#january</a>
                </div>
                {/* .tags-links */}
              </header>
              {/* .entry-header */}
            </div>
            {/* .recent-post-wrap */}
            <div className="recent-post-wrap">
              <figure>
                <img src="images/thumb-2.jpg" alt="" />
              </figure>
              <header className="entry-header">
                <div className="posted-date">January 30, 2018</div>
                {/* .entry-header */}
                <h3>
                  <a href="#">My fall in love story</a>
                </h3>
                <div className="tags-links">
                  <a href="#">#winter</a>
                  <a href="#">#love</a>
                  <a href="#">#snow</a>
                  <a href="#">#january</a>
                </div>
                {/* .tags-links */}
              </header>
              {/* .entry-header */}
            </div>
            {/* .recent-post-wrap */}
          </div>
          {/* .recent-posts */}
          <div className="tags-list">
            <a href="#">Music</a>
            <a href="#">Love</a>
            <a href="#">Car</a>
            <a href="#">Stories</a>
            <a href="#">Photography</a>
            <a href="#">Music</a>
            <a href="#">Car</a>
          </div>
          {/* .tags-list */}
        </div>
        {/* .sidebar */}
      </div>
      {/* .col */}
    </div>
    {/* .row */}
  </div>
  {/* .container */}
  {/* .outer-container */}
</>

  )
}

export default Contact
