import React from 'react';
import './App.css';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './components/Home';
import About from './components/About';
import Contact from './components/Contact';
import Blog from './components/Blog';
import {BrowserRouter, Routes, Route} from 'react-router-dom';

function App() {
  return (
    <>
    <Header />
      <BrowserRouter>
      <Routes>
        <Route path='/index.html' element={<Home />}/>
        <Route path='/about.html' element={<About />}/>
        <Route path='/contact.html' element={<Contact />}/>
        <Route path='/blog.html' element={<Blog />}/>
      </Routes>
      </BrowserRouter>
      <Footer/>
    </>
  );
}

export default App;
